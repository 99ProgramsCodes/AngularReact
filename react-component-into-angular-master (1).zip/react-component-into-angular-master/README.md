# Embedding React in Angular

This project shows how to embed a React component within an Angular application, 
in a simple way and without any complex 3rd party libraries. 

## Run

Run `ng serve --open`

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).
